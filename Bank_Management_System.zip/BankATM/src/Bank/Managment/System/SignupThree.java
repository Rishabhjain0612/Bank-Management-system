package Bank.Managment.System;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;

public class SignupThree extends JFrame implements ActionListener{
	JRadioButton r1,r2,r3,r4;
	 JCheckBox c1,c2,c3,c4,c5,c6,c7;
	 JButton cancel,sumbit;
	 String formno;
	SignupThree(String formno){
		
		this.formno=formno;
		
		setLayout(null);
		
		JLabel accountDetail=new JLabel("Page 3: Account Details");
		accountDetail.setFont(new Font("Raleway",Font.BOLD,22)) ;
		accountDetail.setBounds(280, 10, 400, 30);
		add(accountDetail);
		
		JLabel type=new JLabel("Account Type");
		type.setFont(new Font("Raleway",Font.BOLD,22)) ;
		type.setBounds(100, 70, 200, 30);
		add(type);
		
		r1=new JRadioButton("Saving Account");
		r1.setFont(new Font("Raleway",Font.BOLD,16));
		r1.setBackground(Color.WHITE);
		r1.setBounds(100,120, 300,20);
		add(r1);
		
		r2=new JRadioButton("Fixed Deposit Account");
		r2.setFont(new Font("Raleway",Font.BOLD,16));
		r2.setBackground(Color.WHITE);
		r2.setBounds(450,120, 300,20);
		add(r2);
		
		r3=new JRadioButton("Current Account");
		r3.setFont(new Font("Raleway",Font.BOLD,16));
		r3.setBackground(Color.WHITE);
		r3.setBounds(100,160, 300,20);
		add(r3);
		
		r4=new JRadioButton("Recurring Deposit Account");
		r4.setFont(new Font("Raleway",Font.BOLD,16));
		r4.setBackground(Color.WHITE);
		r4.setBounds(450,160, 300,20);
		add(r4);
		
		ButtonGroup accountgroup =new ButtonGroup();
		accountgroup.add(r1);
		accountgroup.add(r2);
		accountgroup.add(r3);
		accountgroup.add(r4);
		
		JLabel card=new JLabel("Card Number");
		card.setFont(new Font("Raleway",Font.BOLD,22)) ;
		card.setBounds(100, 210, 200, 30);
		add(card);
		
		JLabel number_card=new JLabel("XXXX-XXXX-XXXX-0123");
		number_card.setFont(new Font("Raleway",Font.BOLD,22)) ;
		number_card.setBounds(330, 210, 300, 30);
		add(number_card);
		
		JLabel card_detail=new JLabel("Your 16 digit Card Number");
		card_detail.setFont(new Font("Raleway",Font.BOLD,12)) ;
		card_detail.setBounds(100, 240, 300, 20);
		add(card_detail);
		
		JLabel pin=new JLabel("Pin Number");
		pin.setFont(new Font("Raleway",Font.BOLD,22)) ;
		pin.setBounds(100, 280, 200, 30);
		add(pin);
		
		JLabel pin_detail=new JLabel("Your 4 digit Pin Number");
		pin_detail.setFont(new Font("Raleway",Font.BOLD,12)) ;
		pin_detail.setBounds(100, 310, 200, 20);
		add(pin_detail);
		
		JLabel pinno=new JLabel("XXXX");
		pinno.setFont(new Font("Raleway",Font.BOLD,22)) ;
		pinno.setBounds(330, 280, 300, 30);
		add(pinno);
		
		JLabel services=new JLabel("Services Required");
		services.setFont(new Font("Raleway",Font.BOLD,22)) ;
		services.setBounds(100, 350, 400, 30);
		add(services);
		
		    c1 = new JCheckBox("ATM CARD");
	        c1.setBackground(Color.WHITE);
	        c1.setFont(new Font("Raleway", Font.BOLD, 16));
	        c1.setBounds(100,400,200,20);
	        add(c1);
	        
	        c2 = new JCheckBox("Internet Banking");
	        c2.setBackground(Color.WHITE);
	        c2.setFont(new Font("Raleway", Font.BOLD, 16));
	        c2.setBounds(330,400,200,20);
	        add(c2);
	        
	        c3 = new JCheckBox("Mobile Banking");
	        c3.setBackground(Color.WHITE);
	        c3.setFont(new Font("Raleway", Font.BOLD, 16));
	        c3.setBounds(100,440,200,20);
	        add(c3);
	        
	        
	        c4 = new JCheckBox("EMAIL Alerts");
	        c4.setBackground(Color.WHITE);
	        c4.setFont(new Font("Raleway", Font.BOLD, 16));
	        c4.setBounds(330,440,200,20);
	        add(c4);
	        
	        c5 = new JCheckBox("Cheque Book");
	        c5.setBackground(Color.WHITE);
	        c5.setFont(new Font("Raleway", Font.BOLD, 16));
	        c5.setBounds(100,480,200,20);
	        add(c5);
	        
	        c6 = new JCheckBox("E-Statement");
	        c6.setBackground(Color.WHITE);
	        c6.setFont(new Font("Raleway", Font.BOLD, 16));
	        c6.setBounds(330,480,200,20);
	        add(c6);
	        
	        c7 = new JCheckBox("I hereby declare that the above entered details are correct to the best of my knowledge");
	        c7.setBackground(Color.WHITE);
	        c7.setFont(new Font("Raleway", Font.BOLD, 12));
	        c7.setBounds(100,530,500,20);
	        add(c7);
	        
	        cancel=new JButton("Cancel");
	        cancel.setBackground(Color.BLACK);
	        cancel.setForeground(Color.WHITE);
	        cancel.setFont(new Font("Raleway", Font.BOLD, 16));
	        cancel.setBounds(220,590,100,30);
	        cancel.addActionListener(this);
	        add(cancel);
	        
	        sumbit=new JButton("Sumbit");
	        sumbit.setBackground(Color.BLACK);
	        sumbit.setForeground(Color.WHITE);
	        sumbit.setFont(new Font("Raleway", Font.BOLD, 16));
	        sumbit.setBounds(420,590,100,30);
	        sumbit.addActionListener(this);
	        add(sumbit);
		
		getContentPane().setBackground(Color.WHITE);
		setSize(850,820);
		setLocation(350,0);
		setVisible(true);
		
	}

	public static void main(String[] args) {
		
		new SignupThree("");

	}

	public void actionPerformed(ActionEvent ae) {
		
		if(ae.getSource()==sumbit) {
			
			String accounttype="";
			
			if(r1.isSelected()) {
				
				accounttype="Saving Account";
			}
			else if(r2.isSelected()) {
				
				accounttype="Fixed Deposit Account";
			}
			else if(r3.isSelected()) {
					
					accounttype="Current Account";
				}
           else if(r4.isSelected()) {
				
				accounttype="Recurring Deposit Account";
			}
			
			 Random ran = new Random();
		        long first7 = (ran.nextLong() % 90000000L) + 5040936000000000L;
		        String cardno = "" + Math.abs(first7);
		        long first=Math.abs(ran.nextLong());
		        long first3 = (first % 9000L) + 1000L;
		        String pin = "" + Math.abs(first3);
		        
		        String facility="";
		        if(c1.isSelected()) {
		        	
		        	facility=facility+" ATM CARD";
		        }
                if(c2.isSelected()) {
		        	
		        	facility=facility+" Internet Banking";
		        }
                if(c3.isSelected()) {
		        	
		        	facility=facility+" Mobile Banking";
		        }
                if(c4.isSelected()) {
		        	
		        	facility=facility+" EMAIL Alerts";
		        }
                if(c5.isSelected()) {
		        	
		        	facility=facility+" Cheque Book";
		        }
                if(c1.isSelected()) {
		        	
		        	facility=facility+" E-Statement";
		        }
                
                
                
                try {
                	
                	if(accounttype.equals("")) {
        				
        				JOptionPane.showMessageDialog(null,"Account type is required");
        			}else {
        				
        				Conn conn=new Conn();
        				String query1="insert into signupthree values('"+formno+"', '"+accounttype+"', '"+cardno+"', '"+pin+"', '"+facility+"')";
        				String query2="insert into login values('"+formno+"', '"+cardno+"', '"+pin+"')";
        				conn.stat.executeUpdate(query1);
        				conn.stat.executeUpdate(query2);
        					
        				JOptionPane.showMessageDialog(null,"Card Number: " + cardno + "\n Pin:"+ pin);
        				setVisible(false);
        				new Deposit(pin).setVisible(true);
        			}
                	
                	
                }catch(Exception e){
                	
                	System.out.println(e);
                }
                
          
           
			
			
		}
		else if(ae.getSource()==cancel) {
			
			setVisible(false);
			new Login().setVisible(true);
			
			
		}
		
		
	}

}
