package Bank.Managment.System;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import com.toedter.calendar.JDateChooser;
import java.awt.event.*;


public class SignupOne extends JFrame implements ActionListener{
	
	long random;
	JTextField nameTextField,fnameTextField,emailTextField,addressTextField,cityTextField,stateTextField,PinTextField;
	JButton next;
	JRadioButton male,female,married,unmarried;
	JDateChooser dateChooser;
	SignupOne(){
		
		setLayout(null);
		
		Random ran=new Random();
		random=Math.abs((ran.nextLong()%9000L)+1000L);
		
		JLabel formno=new JLabel("Application Form No. "+random);
		formno.setFont(new Font("Raleway",Font.BOLD,38)) ;
		formno.setBounds(140, 10, 600, 40);
		add(formno);
		
		JLabel personDetail=new JLabel("Page 1: Personal Details");
		personDetail.setFont(new Font("Raleway",Font.BOLD,22)) ;
		personDetail.setBounds(290, 60, 400, 30);
		add(personDetail);
		
		JLabel name=new JLabel("Name: ");
		name.setFont(new Font("Raleway",Font.BOLD,20)) ;
		name.setBounds(100,120, 100, 30);
		add(name);
		
		 nameTextField=new JTextField();
		nameTextField.setFont(new Font("Raleway",Font.BOLD,20));
		nameTextField.setBounds(300,120,400,30);
		add(nameTextField);
		
		JLabel fname=new JLabel("Father's Name: ");
		fname.setFont(new Font("Raleway",Font.BOLD,20)) ;
		fname.setBounds(100,170, 200, 30);
		add(fname);
		
		fnameTextField=new JTextField();
		fnameTextField.setFont(new Font("Raleway",Font.BOLD,20));
		fnameTextField.setBounds(300,170,400,30);
		add(fnameTextField);
		
		JLabel dob=new JLabel("Date of Birth: ");
		dob.setFont(new Font("Raleway",Font.BOLD,20)) ;
		dob.setBounds(100,220, 200, 30);
		add(dob);
		
		dateChooser=new JDateChooser();
		dateChooser.setBounds(300,220,400,30);
		dateChooser.setForeground(new Color(105,105,105));
		add(dateChooser);
		
		JLabel gender=new JLabel("Gender: ");
		gender.setFont(new Font("Raleway",Font.BOLD,20)) ;
		gender.setBounds(100,270, 200, 30);
		add(gender);
		
		male=new JRadioButton("Male");
		male.setBounds(300, 270, 60, 30);
		male.setBackground(Color.WHITE);
		add(male);
		
		female=new JRadioButton("Female");
		female.setBounds(450, 270, 120, 30);
		female.setBackground(Color.WHITE);
		add(female);
		
		ButtonGroup gendergroup =new ButtonGroup();
		gendergroup.add(male);
		gendergroup.add(female);
		
        JLabel email=new JLabel("Email Address: ");
        email.setFont(new Font("Raleway",Font.BOLD,20)) ;
        email.setBounds(100,320, 200, 30);
		add(email);
		
		 emailTextField=new JTextField();
		emailTextField.setFont(new Font("Raleway",Font.BOLD,20));
		emailTextField.setBounds(300,320,400,30);
		add(emailTextField);
		
		 JLabel marital=new JLabel("Marital status: ");
		 marital.setFont(new Font("Raleway",Font.BOLD,20)) ;
		 marital.setBounds(100,370, 200, 30);
		add(marital);
		
		married=new JRadioButton("Married");
		married.setBounds(300, 370, 120, 30);
		married.setBackground(Color.WHITE);
		add(married);
		
		 unmarried=new JRadioButton("Unmarried");
		unmarried.setBounds(450, 370, 120, 30);
		unmarried.setBackground(Color.WHITE);
		add(unmarried);
		
		ButtonGroup maritalgroup =new ButtonGroup();
		maritalgroup.add(married);
		maritalgroup.add(unmarried);
			
		JLabel address=new JLabel("Address: ");
		address.setFont(new Font("Raleway",Font.BOLD,20)) ;
		address.setBounds(100,420, 200, 30);
		add(address);
		
		addressTextField=new JTextField();
		addressTextField.setFont(new Font("Raleway",Font.BOLD,20));
		addressTextField.setBounds(300,420,400,30);
		add(addressTextField);
		
		JLabel city=new JLabel("City: ");
		city.setFont(new Font("Raleway",Font.BOLD,20)) ;
		city.setBounds(100,470, 200, 30);
		add(city);
		
		cityTextField=new JTextField();
		cityTextField.setFont(new Font("Raleway",Font.BOLD,20));
		cityTextField.setBounds(300,470,400,30);
		add(cityTextField);
		
		JLabel state=new JLabel("State: ");
		state.setFont(new Font("Raleway",Font.BOLD,20)) ;
		state.setBounds(100,520, 200, 30);
		add(state);
		
		stateTextField=new JTextField();
		stateTextField.setFont(new Font("Raleway",Font.BOLD,20));
		stateTextField.setBounds(300,520,400,30);
		add(stateTextField);
		
		JLabel Pincode=new JLabel("Pincode: ");
		Pincode.setFont(new Font("Raleway",Font.BOLD,20)) ;
		Pincode.setBounds(100,570, 200, 30);
		add(Pincode);
		
		 PinTextField=new JTextField();
		PinTextField.setFont(new Font("Raleway",Font.BOLD,20));
		PinTextField.setBounds(300,570,400,30);
		add(PinTextField);
		
		 next =new JButton("Next");
		next.setBackground(Color.BLACK);
		next.setForeground(Color.WHITE);
		next.setBounds(600, 630, 80, 30);
		next.addActionListener(this);
		add(next);
		
		getContentPane().setBackground(Color.WHITE);
		setSize(850,800);
		setLocation(300,5);
		setVisible(true);
		
		
	}

	public static void main(String[] args) {
		new SignupOne();

	}
	
	public void actionPerformed(ActionEvent ae) {
		String formno=""+random;
		String name=nameTextField.getText();
		String fname=fnameTextField.getText();
		String dob=((JTextField)dateChooser.getDateEditor().getUiComponent()).getText();
		String gender="";
		if(male.isSelected()) {
			
			gender="Male";
		}
		else if(female.isSelected()) {
			
			gender="Female";
		}
		String email=emailTextField.getText();
		String marital="";
		if(married.isSelected()) {
			
			marital="Married";
		}
		else if(unmarried.isSelected()) {
			
			marital="Unmarried";
		}
		
		String address=addressTextField.getText();
		String city=cityTextField.getText();
		String state=stateTextField.getText();
		String pin=PinTextField.getText();
		
		try {  
			
			if(name.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Name is Required");
			}
			else if(fname.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Father's Name is Required");
			}
           else if(dob.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Date of birth is Required");
			}
           else if(gender.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Gender is Required");
			}
           else if(email.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Email is Required");
			}
           else if(marital.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Marital status is Required");
			}
           else if(address.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Address is Required");
			}
           else if(city.equals("")) {
				
				JOptionPane.showMessageDialog(null,"City is Required");
			}
           else if(state.equals("")) {
				
				JOptionPane.showMessageDialog(null,"State is Required");
			}
           else if(pin.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Pin is Required");
			}
           else {
        	   Conn c=new Conn();
        	   String query="insert into signup values('"+formno+"', '"+name+"', '"+fname+"', '"+dob+"', '"+gender+"', '"+email+"', '"+marital+"', '"+address+"', '"+city+"', '"+pin+"', '"+state+"')";
        	   c.stat.executeUpdate(query);
        	   
        	   setVisible(false);
        	   new SignupTwo(formno).setVisible(true);
           }
			
			
			
			
			
			
			
			
			
			
		}catch(Exception e) {
			
			System.out.println(e);
		}
	}

}
