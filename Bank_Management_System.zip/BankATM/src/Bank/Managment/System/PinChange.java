package Bank.Managment.System;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PinChange extends JFrame implements ActionListener{
	JPasswordField pintextchange,repintextchange;
	JButton change,back;
	String pinnumber;
	PinChange(String pinnumber){
		this.pinnumber=pinnumber;
		setLayout(null);
		
		ImageIcon i1=new ImageIcon(getClass().getResource("atm.jpg"));
		Image i2=i1.getImage().getScaledInstance(900,900, Image.SCALE_DEFAULT);
		ImageIcon i3=new ImageIcon(i2);
		JLabel image=new JLabel(i3);
		image.setBounds(0,0,900,900);
		add(image);
		
		JLabel text=new JLabel("Change your Pin");
		text.setBounds(270,280,400,35);
		text.setForeground(Color.WHITE);
		text.setFont(new Font("System",Font.BOLD,16));
		image.add(text);
		
		JLabel pinchange=new JLabel("New PIN:");
		pinchange.setBounds(165,320,180,25);
		pinchange.setForeground(Color.WHITE);
		pinchange.setFont(new Font("System",Font.BOLD,16));
		image.add(pinchange);
		
		pintextchange=new JPasswordField();
		pintextchange.setFont(new Font("Raleway",Font.BOLD,25));
		pintextchange.setBounds(330,320,180,25);
			add(pintextchange);
			
		
		JLabel repinchange=new JLabel("Re-Enter New PIN:");
		repinchange.setBounds(165,360,180,25);
		repinchange.setForeground(Color.WHITE);
		repinchange.setFont(new Font("System",Font.BOLD,16));
		image.add(repinchange);
		
		
		repintextchange=new JPasswordField();
		repintextchange.setFont(new Font("Raleway",Font.BOLD,25));
		repintextchange.setBounds(330,360,180,25);
			add(repintextchange);
			
			 change=new JButton("CHANGE");
			 change.setBackground(Color.WHITE);
			 change.setForeground(Color.BLACK);
			 change.setFont(new Font("Raleway", Font.BOLD, 16));
			 change.setBounds(355,485,150,30);
			 change.addActionListener(this);
		        image.add(change);
		        
		        back=new JButton("BACK");
		        back.setBackground(Color.WHITE);
		        back.setForeground(Color.BLACK);
		        back.setFont(new Font("Raleway", Font.BOLD, 16));
		        back.setBounds(355,520,150,30);
		        back.addActionListener(this);
			        image.add(back);
			
			
			
		
		
		setSize(900,900);
		setLocation(300,0);
		setVisible(true);
		
	}
	

	public static void main(String[] args) {
		
		new PinChange("").setVisible(true);

	}


	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==change) {
		try {
			
			String npin=pintextchange.getText();
			String rpin=repintextchange.getText();
			
			if(!npin.equals(rpin)) {
				
				JOptionPane.showMessageDialog(null,"Entered Pin and Re-pin does not match");
				return;
			}
			
			if(npin.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Please enter new Pin");
				return;
			}
			
			else if(rpin.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Please re-enter new Pin");
				return;
			}
			
			else if(npin.length()!=4) {
				
				JOptionPane.showMessageDialog(null,"Please enter 4 digit pin");
				return;
			}
           
           Conn c1 = new Conn();
           String q1 = "update bank set pin = '"+npin+"' where Pin = '"+pinnumber+"' ";
           String q2 = "update login set pin = '"+npin+"' where Pin = '"+pinnumber+"' ";
           String q3 = "update signupthree set pin = '"+npin+"' where Pin = '"+pinnumber+"' ";

           c1.stat.executeUpdate(q1);
           c1.stat.executeUpdate(q2);
           c1.stat.executeUpdate(q3);

           JOptionPane.showMessageDialog(null, "PIN changed successfully");
           setVisible(false);
           new Transactions(rpin).setVisible(true);
			
			
		}catch(Exception ae) {
			
			System.out.println(ae);
		}
		}
		else {
			
			setVisible(false);
			new Transactions(pinnumber).setVisible(true);
		}
		
	}

}
