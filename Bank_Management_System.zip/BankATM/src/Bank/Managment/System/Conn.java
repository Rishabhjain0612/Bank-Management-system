package Bank.Managment.System;
import java.sql.*;

public class Conn {
	
	 Connection c;
	 Statement stat;    

	public Conn() {
		
		
		try {
			
			//Class.forName(com.mysql.cj.jdbc.Driver);Automatic registers 
			c=DriverManager.getConnection("jdbc:mysql:///bankmanagementsystem", "root", "Rishsunil123#");
			stat=c.createStatement();
		}catch(Exception e){
			
			System.out.println(e);
			
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
