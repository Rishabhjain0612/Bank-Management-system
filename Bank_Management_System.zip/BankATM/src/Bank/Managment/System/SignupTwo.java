package Bank.Managment.System;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import com.toedter.calendar.JDateChooser;
import java.awt.event.*;

import com.toedter.calendar.JDateChooser;

public class SignupTwo extends JFrame implements ActionListener {
	JComboBox religioncombo,categorycombo;
	JTextField incomeTextField,fincomeTextField,QualifyTextField,occupationTextField,panTextField,aadharTextField;
	JButton next;
	JRadioButton yes,no,yes1,no1;
	String formno;
	
	SignupTwo(String formno){
		
			this.formno=formno;
			setLayout(null);
			
			JLabel AdditionalDetail=new JLabel("Page 2: Additional Details");
			AdditionalDetail.setFont(new Font("Raleway",Font.BOLD,22)) ;
			AdditionalDetail.setBounds(290, 60, 400, 30);
			add(AdditionalDetail);
			
			JLabel Religion=new JLabel("Religion: ");
			Religion.setFont(new Font("Raleway",Font.BOLD,20)) ;
			Religion.setBounds(100,120, 100, 30);
			add(Religion);
			
			String v1[]= {"Hindu", "Muslim", "Christian", "Jainism"};
			religioncombo=new JComboBox(v1);
			religioncombo.setBounds(300,120,400,30);
			religioncombo.setBackground(Color.WHITE);
			add(religioncombo);
			
			JLabel category=new JLabel("Category: ");
			category.setFont(new Font("Raleway",Font.BOLD,20)) ;
			category.setBounds(100,170, 200, 30);
			add(category);
			
			String v2[]= {"General", "OBC", "SC", "ST"};
			categorycombo=new JComboBox(v2);
			categorycombo.setBounds(300,170,400,30);
			categorycombo.setBackground(Color.WHITE);
			add(categorycombo);
			
			
			
			JLabel income=new JLabel("Income: ");
			income.setFont(new Font("Raleway",Font.BOLD,20)) ;
			income.setBounds(100,220, 200, 30);
			add(income);
			
			incomeTextField=new JTextField();
			incomeTextField.setFont(new Font("Raleway",Font.BOLD,20));
			incomeTextField.setBounds(300,220,400,30);
			add(incomeTextField);
			
			
			JLabel fincome=new JLabel("Father's income: ");
			fincome.setFont(new Font("Raleway",Font.BOLD,20)) ;
			fincome.setBounds(100,270, 200, 30);
			add(fincome);
			
			fincomeTextField=new JTextField();
			fincomeTextField.setFont(new Font("Raleway",Font.BOLD,20));
			fincomeTextField.setBounds(300,270,400,30);
			add(fincomeTextField);
			
			
	        JLabel qualify=new JLabel("Qualification: ");
	        qualify.setFont(new Font("Raleway",Font.BOLD,20)) ;
	        qualify.setBounds(100,320, 200, 30);
			add(qualify);
			
			QualifyTextField=new JTextField();
			QualifyTextField.setFont(new Font("Raleway",Font.BOLD,20));
			QualifyTextField.setBounds(300,320,400,30);
			add(QualifyTextField);
			
			
			 JLabel occupation=new JLabel("Occupation: ");
			 occupation.setFont(new Font("Raleway",Font.BOLD,20)) ;
			 occupation.setBounds(100,370, 200, 30);
			add(occupation);
			
			occupationTextField=new JTextField();
			occupationTextField.setFont(new Font("Raleway",Font.BOLD,20));
			occupationTextField.setBounds(300,370,400,30);
			add(occupationTextField);
				
			JLabel Pan=new JLabel("Pan Number: ");
			Pan.setFont(new Font("Raleway",Font.BOLD,20)) ;
			Pan.setBounds(100,420, 200, 30);
			add(Pan);
			
			panTextField=new JTextField();
			panTextField.setFont(new Font("Raleway",Font.BOLD,20));
			panTextField.setBounds(300,420,400,30);
			add(panTextField);
			
			JLabel aadhar=new JLabel("Aadhar No: ");
			aadhar.setFont(new Font("Raleway",Font.BOLD,20)) ;
			aadhar.setBounds(100,470, 200, 30);
			add(aadhar);
			
			aadharTextField=new JTextField();
			aadharTextField.setFont(new Font("Raleway",Font.BOLD,20));
			aadharTextField.setBounds(300,470,400,30);
			add(aadharTextField);
			
			JLabel senior=new JLabel("Senior Citizen: ");
			senior.setFont(new Font("Raleway",Font.BOLD,20)) ;
			senior.setBounds(100,520, 200, 30);
			add(senior);
			
			yes=new JRadioButton("YES");
			yes.setBounds(300, 520, 60, 30);
			yes.setBackground(Color.WHITE);
			add(yes);
			
			no=new JRadioButton("NO");
			no.setBounds(450, 520, 120, 30);
			no.setBackground(Color.WHITE);
			add(no);
			
			ButtonGroup seniorgroup =new ButtonGroup();
			seniorgroup.add(yes);
			seniorgroup.add(no);
			
			JLabel existing=new JLabel("Existing Account: ");
			existing.setFont(new Font("Raleway",Font.BOLD,20)) ;
			existing.setBounds(100,570, 200, 30);
			add(existing);
			
			yes1=new JRadioButton("YES");
			yes1.setBounds(300, 570, 60, 30);
			yes1.setBackground(Color.WHITE);
			add(yes1);
			
			no1=new JRadioButton("NO");
			no1.setBounds(450, 570, 120, 30);
			no1.setBackground(Color.WHITE);
			add(no1);
			
			ButtonGroup existgroup =new ButtonGroup();
			existgroup.add(yes1);
			existgroup.add(no1);
			
			
			 next =new JButton("Next");
			next.setBackground(Color.BLACK);
			next.setForeground(Color.WHITE);
			next.setBounds(600, 630, 80, 30);
			next.addActionListener(this);
			add(next);
			
			getContentPane().setBackground(Color.WHITE);
			setSize(850,800);
			setLocation(300,5);
			setVisible(true);
		
		
		
		
	}

	public static void main(String[] args) {
	   
		new SignupTwo("");
		

	}
	
	public void actionPerformed(ActionEvent ae) {
		//String formno=""+random;
		String religion=(String)religioncombo.getSelectedItem();
		String category=(String)categorycombo.getSelectedItem();
		String income=incomeTextField.getText();
		String fincome=fincomeTextField.getText();
		String qualify=QualifyTextField.getText();
		String occupation=occupationTextField.getText();
		String Pan=panTextField.getText();
		String aadhar=aadharTextField.getText();
		String senior="";
       if(yes.isSelected()) {
			
			senior="YES";
		}
		else if(no.isSelected()) {
			
			senior="NO";
		}
		
		String existing="";
		
		 if(yes1.isSelected()) {
				
				existing="YES";
			}
			else if(no1.isSelected()) {
				
				existing="NO";
			}
		
		
		try {  
			
			if(religion.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Religion is Required");
			}
			else if(category.equals("")) {
				
				JOptionPane.showMessageDialog(null,"category is Required");
			}
           else if(income.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Income is Required");
			}
           else if(fincome.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Father's Income is Required");
			}
           else if(qualify.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Qualification specification is Required");
			}
           else if(occupation.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Occupation specification is Required");
			}
           else if(Pan.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Pan Number is Required");
			}
           else if(aadhar.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Aadhar Number is required");
			}
           else if(senior.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Please tick the senior citizen box");
			}
           else if(existing.equals("")) {
				
				JOptionPane.showMessageDialog(null,"Please let us know u have existing account or not");
			}
           else {
        	   Conn c=new Conn();
        	   String query="insert into signuptwo values('"+formno+"', '"+religion+"', '"+category+"', '"+income+"', '"+fincome+"', '"+qualify+"', '"+occupation+"', '"+Pan+"', '"+aadhar+"', '"+senior+"', '"+existing+"')";
        	   c.stat.executeUpdate(query);
        	   
        	   setVisible(false);
        	   new SignupThree(formno).setVisible(true);
           }
			
			
		}catch(Exception e) {
			
			System.out.println(e);
		}
	}


}
