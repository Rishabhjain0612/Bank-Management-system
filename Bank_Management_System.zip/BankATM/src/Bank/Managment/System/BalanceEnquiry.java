package Bank.Managment.System;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.*;
import java.sql.ResultSet;
import java.sql.*;

import javax.swing.*;

public class BalanceEnquiry extends JFrame implements ActionListener{
	JButton back;
	String pinnumber;
	BalanceEnquiry(String pinnumber){
		this.pinnumber=pinnumber;
		setLayout(null);
		
		ImageIcon i1=new ImageIcon(getClass().getResource("atm.jpg"));
		Image i2=i1.getImage().getScaledInstance(900,900, Image.SCALE_DEFAULT);
		ImageIcon i3=new ImageIcon(i2);
		JLabel image=new JLabel(i3);
		image.setBounds(0,0,900,900);
		add(image);
		
		back=new JButton("Back");
		back.setBounds(355,520, 150, 30);
		back.addActionListener(this);
		image.add(back);
		
		Conn c=new Conn();
		int balance=0;
//		JLabel text=new JLabel("Your current Account balance is Rs " + balance);
//        text.setFont(new Font("Osward",Font.BOLD,38));
//        text.setBackground(Color.BLUE);
//        text.setForeground(Color.WHITE);
//        text.setBounds(200,40,400,40);
//        image.add(text);
		try {
		ResultSet rs=c.stat.executeQuery("select * from bank where Pin='"+pinnumber+"'");
		
		
		while(rs.next()) {
			
			if(rs.getString("Type").equals("Deposit")) {
				
				balance+=Integer.parseInt(rs.getString("Amount"));
			}
			else {
				
				balance-=Integer.parseInt(rs.getString("Amount"));
			}
		}
		}catch(Exception e) {
			
			System.out.println(e);
		}
		
		 JLabel text=new JLabel("Your current Account balance is Rs " + balance);
	        text.setFont(new Font("Osward",Font.BOLD,18));
	        text.setBackground(Color.BLUE);
	        text.setForeground(Color.WHITE);
	        text.setBounds(160,320,800,40);
	        image.add(text);
		
		setSize(900,900);
		setLocation(300,0);
		setVisible(true);
	}

	public static void main(String[] args) {
	
		new BalanceEnquiry("");

	}

	public void actionPerformed(ActionEvent e) {
		
		setVisible(false);
		new Transactions(pinnumber).setVisible(true);
		
	}

}
